
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr" >

<head>

<meta name="viewport" content="initial-scale=1.0,width=device-width" />
  <base href="http://www.cimcoinc.net/index.php" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="generator" content="Joomla! 1.5 - Open Source Content Management" />
  <title></title>
  <link href="/index.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
  <link href="/index.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
  <link href="/templates/joomspirit_70/favicon.ico" rel="shortcut icon" type="image/x-icon" />
  <link rel="stylesheet" href="/modules/mod_ariimageslider/mod_ariimageslider/js/themes/nivo-slider.css" type="text/css" />
  <link rel="stylesheet" href="/modules/mod_ariimageslider/mod_ariimageslider/js/themes/default/style.css" type="text/css" />
  <style type="text/css">
    <!--
#ais_16_wrapper,#ais_16{width:980px;height:400px;}
    -->
  </style>
  <script type="text/javascript" src="/plugins/system/mtupgrade/mootools.js"></script>
  <script type="text/javascript" src="/media/system/js/caption.js"></script>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
  <script type="text/javascript" src="/modules/mod_ariimageslider/mod_ariimageslider/js/jquery.noconflict.js"></script>
  <script type="text/javascript" src="/modules/mod_ariimageslider/mod_ariimageslider/js/jquery.nivo.slider.js"></script>
  <script type="text/javascript">
jQuery(window).load(function() { var $ = window.jQueryNivoSlider || jQuery; $("#ais_16").nivoSlider(); });
  </script>
  <!--[if lt IE 7]><link rel="stylesheet" href="/modules/mod_ariimageslider/mod_ariimageslider/js/themes/default/style.ie6.css" type="text/css" /><![endif]-->
  <!--[if IE]><link rel="stylesheet" href="/modules/mod_ariimageslider/mod_ariimageslider/js/themes/default/style.ie.css" type="text/css" /><![endif]-->


<!--	Google fonts	-->
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:300" />
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=arial" />

<!-- style sheet links -->
<link rel="stylesheet" href="/templates/system/css/general.css" type="text/css" media="screen" />
<link rel="stylesheet" href="/templates/joomspirit_70/css/main.css" type="text/css" media="all" />
<link rel="stylesheet" href="/templates/joomspirit_70/css/nav.css" type="text/css" media="all" />
<link rel="stylesheet" href="/templates/joomspirit_70/css/template.css" type="text/css" media="all" />
<link rel="stylesheet" href="/templates/joomspirit_70/css/theme_red.css" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="/templates/joomspirit_70/css/dynamic_css.php&#63;font=Open+Sans:300&amp;font_content=arial&amp;colorh2=006d98&amp;width=980px&amp;width_left=20&amp;width_right=20" media="all" />
<link rel="stylesheet" href="/templates/joomspirit_70/css/media_queries.css" type="text/css" media="screen" />
<link rel="stylesheet" href="/templates/joomspirit_70/css/print.css" type="text/css" media="print" />

<!--[if lte IE 8]>
<link rel="stylesheet" href="/templates/joomspirit_70/css/ie8.css" type="text/css" />
<script type="text/javascript" src="/templates/joomspirit_70/lib/js/html5.js"></script>
<script type="text/javascript" src="/templates/joomspirit_70/lib/js/css3-mediaqueries.js"></script>	
		
<![endif]-->
<!--[if lte IE 7]>
<link rel="stylesheet" href="/templates/joomspirit_70/css/ie7.css" type="text/css" />
<![endif]-->

</head>
<body style="font-size:0.85em;" >


	<div class="site">
	
		<header>
				
						<div class="logo" >
							
				<a href="/index.php">
				<p><img src="/images/stories/logo.gif" border="0" /></p>				</a>
			
			
			
			</div>
						
			
						<nav class="top_menu">
						<div class="moduletable">
					<ul class="menu"><li class="item15"><a href="/index.php/about-us-who-we-are"><span>About us</span></a></li><li class="item17"><a href="/index.php/jobs"><span>Jobs</span></a></li></ul>		</div>
	
			</nav>	
			
			<div class="website-icons">

								<div id="translate">
							<div class="moduletable">
					<p>Call <strong><span style="color: red;">Cimco</span> </strong>today! (501) 565-2922</p>		</div>
	
				</div>	
								
				<!--	SOCIAL LINKS	-->
								<div id="social-links">
				<ul>
				
										<li><g:plusone  size="small" count="false"></g:plusone></li>
										
							
								
																																	
																										
						
						
										
					
				</ul>
				</div>
								
			</div> 			<!-- 	end of Website icons 		-->	
		
			<div class="clr"></div>
			
		</header>
		
		
		<div class="navigation">
		
			<nav class="nav_main">
							<div class="moduletable dropdown" >
		
								
					<div class="content-module">
						<ul class="menu"><li id="current" class="active item1"><a href="http://www.cimcoinc.net/"><span>Home</span></a></li><li class="parent item2"><a href="/index.php/services-provided"><span>Services</span></a><ul><li class="item3"><a href="/index.php/services-provided/millwright"><span>Millwright</span></a></li><li class="item13"><a href="/index.php/services-provided/maintenance"><span>Maintenance</span></a></li><li class="item14"><a href="/index.php/services-provided/utility-contractor"><span>Utility Contractor</span></a></li><li class="item6"><a href="/index.php/services-provided/foundations"><span>Foundations</span></a></li><li class="item7"><a href="/index.php/services-provided/safety"><span>Safety</span></a></li></ul></li><li class="item18"><a href="/index.php/contact-us"><span>Contact Us</span></a></li></ul>					</div>
		
			</div>
			
			</nav>
			
						<div id="search">
						<div class="moduletable">
					<form action="index.php" method="post">
	<div class="search">
		<input name="searchword" id="mod_search_searchword" maxlength="20" alt="Search" class="inputbox" type="text" size="20" value="search..."  onblur="if(this.value=='') this.value='search...';" onfocus="if(this.value=='search...') this.value='';" />	</div>
	<input type="hidden" name="task"   value="search" />
	<input type="hidden" name="option" value="com_search" />
	<input type="hidden" name="Itemid" value="1" />
</form>		</div>
	
			</div>	
						
			<div class="clr"></div>
		
		</div> 		<!-- 	end of Navigation 		-->
		
			
				<div class="top" >
					<div class="moduletable">
					<div id="ais_16_wrapper" class="ari-image-slider-wrapper ari-is-theme-default ari-image-slider-wCtrlNav">
	<div id="ais_16" class="ari-image-slider nivoSlider">
					<img src="/images/slide/100_0060-001.jpg" alt="" title="" class="imageslider-item" />
							<img src="/images/slide/100_0147.jpg" alt="" title="" class="imageslider-item" style="display:none" />
							<img src="/images/slide/100_0150.jpg" alt="" title="" class="imageslider-item" style="display:none" />
							<img src="/images/slide/146.jpg" alt="" title="" class="imageslider-item" style="display:none" />
							<img src="/images/slide/ACME PHOTO1.jpg" alt="" title="" class="imageslider-item" style="display:none" />
							<img src="/images/slide/DSC01393.jpg" alt="" title="" class="imageslider-item" style="display:none" />
							<img src="/images/slide/scan0001.jpg" alt="" title="" class="imageslider-item" style="display:none" />
							<img src="/images/slide/scan008001.jpg" alt="" title="" class="imageslider-item" style="display:none" />
					<div class="nivo-controlNavHolder">
			<div class="nivo-controlNav">
							<a rel="0" class="nivo-control active">
					<span style="width:px;height:px" class="nivo-thumbNavWrapper">
						0						<span class="nivo-arrow-border"></span>
						<span class="nivo-arrow"></span>
					</span>
				</a>
							<a rel="1" class="nivo-control">
					<span style="width:px;height:px" class="nivo-thumbNavWrapper">
						1						<span class="nivo-arrow-border"></span>
						<span class="nivo-arrow"></span>
					</span>
				</a>
							<a rel="2" class="nivo-control">
					<span style="width:px;height:px" class="nivo-thumbNavWrapper">
						2						<span class="nivo-arrow-border"></span>
						<span class="nivo-arrow"></span>
					</span>
				</a>
							<a rel="3" class="nivo-control">
					<span style="width:px;height:px" class="nivo-thumbNavWrapper">
						3						<span class="nivo-arrow-border"></span>
						<span class="nivo-arrow"></span>
					</span>
				</a>
							<a rel="4" class="nivo-control">
					<span style="width:px;height:px" class="nivo-thumbNavWrapper">
						4						<span class="nivo-arrow-border"></span>
						<span class="nivo-arrow"></span>
					</span>
				</a>
							<a rel="5" class="nivo-control">
					<span style="width:px;height:px" class="nivo-thumbNavWrapper">
						5						<span class="nivo-arrow-border"></span>
						<span class="nivo-arrow"></span>
					</span>
				</a>
							<a rel="6" class="nivo-control">
					<span style="width:px;height:px" class="nivo-thumbNavWrapper">
						6						<span class="nivo-arrow-border"></span>
						<span class="nivo-arrow"></span>
					</span>
				</a>
							<a rel="7" class="nivo-control">
					<span style="width:px;height:px" class="nivo-thumbNavWrapper">
						7						<span class="nivo-arrow-border"></span>
						<span class="nivo-arrow"></span>
					</span>
				</a>
						</div>
		</div>
		</div>
</div>		</div>
	
		</div>
					
		
		
		<div class="middle-site">
		
		
						
				
						<div class="left_column" >
							<div class="moduletable " >
		
										<h3 class="module">Cimco,<span> Inc. is commited to safety</span></h3>
								
					<div class="content-module">
						<p> </p>
<p>It is our intention to maintain a clean, healthy, safe and pleasant workplace not only for our employees but also for our customers.  Our goal is to eliminate injuries in our work place by eliminating unsafe acts and conditions through education and training.</p>
<p> </p>					</div>
		
			</div>
			
			</div>
						
			
	
			<!--  RIGHT COLUMN -->
			<div class="right_column">					
					
				<!--  USER 1, 2, 3 -->
				  <!--	END OF USERS TOP	-->
				
				<div id="main_component" >
				
										<aside class="right-module-position" >
									<div class="moduletable " >
		
										<h3 class="module">We<span> look forward</span></h3>
								
					<div class="content-module">
						<p> </p>
<p>To providing services for any needs you may have, and to building a mutually satisfying long term business<br />relationship</p>
<p> </p>					</div>
		
			</div>
			
					</aside>
									
				
					<div class="main-content">
						
						<!--  MAIN COMPONENT -->
						
						<h1 class="componentheading">
		</h1>
<section class="blog">
			<div class="leading">
			<p class="buttonheading">
	<a href="/index.php?view=article&amp;id=2:welcome&amp;format=pdf" title="PDF" onclick="window.open(this.href,'win2','status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no'); return false;" rel="nofollow"><img src="/templates/joomspirit_70/images/pdf_button.png" alt="PDF"  /></a><a href="/index.php?view=article&amp;id=2:welcome&amp;tmpl=component&amp;print=1&amp;layout=default&amp;page=" title="Print" onclick="window.open(this.href,'win2','status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no'); return false;" rel="nofollow"><img src="/templates/joomspirit_70/images/printButton.png" alt="Print"  /></a><a href="/index.php/component/mailto/?tmpl=component&amp;link=a64ce48968d56c82afc79bd867582cf99ae8aab9" title="E-mail" onclick="window.open(this.href,'win2','width=400,height=350,menubar=yes,resizable=yes'); return false;"><img src="/templates/joomspirit_70/images/emailButton.png" alt="E-mail"  /></a></p>
<h2 class="contentheading">
	Welcome</h2>

<article class="text-article">
<p><span style="text-align: left;"><img class="caption" src="/images/stories/fullscreen capture 332012 92029 pm.bmp.jpg" border="0" alt="Underground Conduit" title="Underground Conduit" align="left" />Cimco, Inc. is a licensed Arkansas General Contractor based in the central Arkansas area. Cimco was established in 1975 and has been serving clients for over 37 years.  Cimco, Inc. can provide everything from site preparation, concrete slab and foundation work and metal buildings to highly technical equipment relocation and installation.  We can be a single source for turnkey projects.  Cimco, Inc. has a dependable fleet of equipment and a skilled workforce to self perform work and also a strong base of qualified specialty subcontractors to handle any of your needs.  Cimco, Inc. can price your project as a hard bid, a not to exceed price or a negotiated price.  We can perform your project on a time and material basis that is competitive with any comparative contractor.</span></p></article>


		</div>
		<span class="leading_separator">&nbsp;</span>
				</section>
						<div style="position:absolute;top:0;left:-9999px;"><a href="http://www.joomspirit.com" title="template joomla">template joomla</a></div>					
					</div>
												
					<div class="clr"></div>
						
				</div>
				
				<!--  USER 4, 5, 6 -->
				  <!--	END OF USERS BOTTOM	-->
				
				<div class="clr"></div>
	
			</div>	  <!--	END OF RIGHT COLUMN 	-->	
				
			<!-- important for left column -->
			<div class="clr"></div>
	
		</div>	<!--	END OF MIDDLE SITE	-->

	</div> 		<!-- 	END OF SITE 		-->
	
	
	<!--		footer		-->
	<footer class="bottom-site">
	
			<!--	bottom nav	-->
						<nav class="bottom_menu">
						<div class="moduletable">
					<p>designed by <a href="http://www.allcomputingnet.com" target="_blank">All Computing Net</a></p>		</div>
	
			</nav>
							
						<div class="address">
						<div class="moduletable">
					<p>© 2012 Cimco, Inc.  8518 Arch Street  Little Rock, AR 72206</p>		</div>
	
			</div>
														
	</footer>	<!--	END OF FOOTER SITE	-->		
		

		<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
	
</body>
</html>